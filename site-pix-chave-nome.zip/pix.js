
// PIX checkout config
const PIX_CONFIG = {
  "pixKey": "14125287988",
  "receiverName": "lojascriptbr",
  "city": "SAO PAULO"
};
