// Utilities
const BRL = new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' });

// State
let PRODUCTS = [];
let CART = [];

const productsEl = document.getElementById('products');
const cartBtn = document.getElementById('cartBtn');
const cartDrawer = document.getElementById('cartDrawer');
const cartItems = document.getElementById('cartItems');
const cartTotal = document.getElementById('cartTotal');
const cartCount = document.getElementById('cartCount');
const closeCart = document.getElementById('closeCart');

// Filters
document.querySelectorAll('.filter-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    const cat = btn.dataset.filter;
    renderProducts(cat === 'all' ? null : cat);
  });
});

// Drawer
cartBtn.onclick = () => { cartDrawer.classList.add('open'); };
closeCart.onclick = () => { cartDrawer.classList.remove('open'); };

// Load products
fetch('products.json')
  .then(r => r.json())
  .then(data => { PRODUCTS = data; renderProducts(); });

function renderProducts(category = null) {
  productsEl.innerHTML = '';
  const items = category ? PRODUCTS.filter(p => p.category === category) : PRODUCTS;
  for (const p of items) {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <div class="thumb"><img alt="" onerror="this.replaceWith(document.createTextNode('Sem imagem'))" src="${p.image || ''}" style="max-width:100%;max-height:100%"></div>
      <div class="body">
        <div class="badges">
          ${p.category ? `<span class="badge">${p.category}</span>` : ''}
          ${p.stock ? `<span class="badge">${p.stock}</span>` : ''}
        </div>
        <div class="title">${p.title}</div>
        <div class="desc">${p.short}</div>
        <div class="price">
          ${p.compare_at ? `<span class="from">${BRL.format(p.compare_at)}</span>` : ''}
          <span class="to">${BRL.format(p.price)}</span>
        </div>
        <div class="actions">
          <button class="add">Adicionar</button>
          <button class="buy">Comprar</button>
        </div>
      </div>`;
    const [addBtn, buyBtn] = card.querySelectorAll('button');
    addBtn.onclick = () => { addToCart(p.id); };
    buyBtn.onclick = () => { addToCart(p.id); cartDrawer.classList.add('open'); };
    productsEl.appendChild(card);
  }
}

function addToCart(id) {
  const item = CART.find(i => i.id === id);
  if (item) item.qty++;
  else {
    const p = PRODUCTS.find(x => x.id === id);
    CART.push({ id: p.id, title: p.title, price: p.price, qty: 1 });
  }
  persistCart();
  renderCart();
}

function changeQty(id, delta) {
  const item = CART.find(i => i.id === id);
  if (!item) return;
  item.qty += delta;
  if (item.qty <= 0) CART = CART.filter(i => i.id !== id);
  persistCart();
  renderCart();
}

function renderCart() {
  cartItems.innerHTML = '';
  let total = 0;
  for (const i of CART) {
    total += i.price * i.qty;
    const row = document.createElement('div');
    row.className = 'cart-item';
    row.innerHTML = `
      <div class="ci-title"><strong>${i.title}</strong><div>${BRL.format(i.price)}</div></div>
      <div class="qty">
        <button aria-label="Diminuir">-</button>
        <div>${i.qty}</div>
        <button aria-label="Aumentar">+</button>
      </div>`;
    const [minus, plus] = row.querySelectorAll('button');
    minus.onclick = () => changeQty(i.id, -1);
    plus.onclick = () => changeQty(i.id, +1);
    cartItems.appendChild(row);
  }
  cartTotal.textContent = BRL.format(total);
  cartCount.textContent = CART.reduce((a,b)=>a+b.qty,0);
  localStorage.setItem('cart_total', total.toFixed(2));
}

function persistCart(){ localStorage.setItem('cart', JSON.stringify(CART)); }
function loadCart() {
  try {
    CART = JSON.parse(localStorage.getItem('cart') || '[]');
  } catch { CART = []; }
  renderCart();
}
loadCart();

// Checkout modal
const checkoutBtn = document.getElementById('checkoutBtn');
const checkoutModal = document.getElementById('checkoutModal');
const closeCheckout = document.getElementById('closeCheckout');
const checkoutTotal = document.getElementById('checkoutTotal');
checkoutBtn.onclick = () => {
  checkoutTotal.textContent = cartTotal.textContent;
  document.getElementById('txid').value = 'PEDIDO-' + Math.random().toString(36).slice(2,8).toUpperCase();
  checkoutModal.classList.add('show');
}
closeCheckout.onclick = () => checkoutModal.classList.remove('show');

document.getElementById('genPix').onclick = () => {
  const key = document.getElementById('pixKey').value.trim();
  const name = document.getElementById('merchantName').value.trim();
  const city = document.getElementById('merchantCity').value.trim();
  const txid = document.getElementById('txid').value.trim().slice(0,25);
  const msg = document.getElementById('pixMsg').value.trim();
  const amount = (parseFloat((localStorage.getItem('cart_total')||'0').replace(',', '.'))||0).toFixed(2);

  if (!key || !name || !city || amount <= 0) {
    alert('Preencha Chave PIX, Nome, Cidade e tenha pelo menos 1 item no carrinho.');
    return;
  }
  const payload = buildPixPayload({ key, name, city, txid, amount, msg });
  const ta = document.getElementById('pixPayload');
  ta.value = payload;
  ta.focus(); ta.select();
  try { document.execCommand('copy'); } catch {}
  const qr = new QRCode(document.getElementById('qrcode'), { text: payload, width: 260, height: 260 });
  // reset QR container for next generation
  setTimeout(() => { document.getElementById('qrcode').innerHTML=''; new QRCode(document.getElementById('qrcode'), { text: payload, width: 260, height: 260 }); }, 0);
};

document.getElementById('copyPayload').onclick = () => {
  const ta = document.getElementById('pixPayload');
  ta.focus(); ta.select(); document.execCommand('copy');
};

document.getElementById('year').textContent = new Date().getFullYear();
